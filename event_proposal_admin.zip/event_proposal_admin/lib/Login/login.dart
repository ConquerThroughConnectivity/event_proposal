
import 'package:event_proposal_admin/Signup/signup.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:progress_button/progress_button.dart';



final double defaultScreenWidth = 420.0;
final double defaultScreenHeight = 820.0;


final TextEditingController username = new TextEditingController();
final TextEditingController password = new TextEditingController();
final formkey = GlobalKey<FormState>();




class Login extends StatefulWidget {
  Login({Key key}) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}



class _LoginState extends State<Login> {

@override
  void dispose() {
    username.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  void initState() {
    
    super.initState();
  }



  @override
  Widget build(BuildContext context) {
    ScreenUtil.instance = ScreenUtil(
      width: defaultScreenWidth,
      height: defaultScreenHeight,
      allowFontScaling: true,
    )..init(context);

      return Scaffold(
        resizeToAvoidBottomPadding: false,
        resizeToAvoidBottomInset: false,
      body: Container(
      padding: EdgeInsets.only(top: 70),
      decoration: BoxDecoration(
        gradient: LinearGradient(
        begin: Alignment.topRight,
        end: Alignment.bottomLeft,
        colors: [Color(0xFF0F2027),Color(0XFF203A43), Color(0XFF2C5364)]),
        ),
        child: Column(
          crossAxisAlignment:CrossAxisAlignment.center,
          children: <Widget>[
            Center(
            child: Text('Event Proposal', style: TextStyle(
            fontFamily: "Mops",
            fontSize: ScreenUtil.instance.setSp(25),
            color: Colors.white
          )),
          ),
          SingleChildScrollView(
            child: Form(
            key: formkey,
            child: Card(
              margin: EdgeInsets.only(
                left: ScreenUtil.instance.setWidth(20.0),
                right: ScreenUtil.instance.setWidth(20.0),
                top: ScreenUtil.instance.setWidth(40.0),
                bottom: ScreenUtil.instance.setWidth(5.0),
              ),
              color: Colors.white70,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
                ),
                elevation: 5.0,
                child: Padding(
                  padding: EdgeInsets.only(top: ScreenUtil.instance.setWidth(30.0), right: ScreenUtil.instance.setWidth(30.0), left: ScreenUtil.instance.setWidth(30.0)),
                  child: Column(
                    children: <Widget>[
                      TextFormField(
                        
                        textInputAction: TextInputAction.done,
                        controller: username,
                        keyboardType: TextInputType.emailAddress,
                        validator: (val){
                          if(val.isEmpty){
                            return 'This field cannot be Empty';
                          }
                        },
                        onChanged: (val){
                          setState(() {
                            val =username.text;
                          });
                        },
                        decoration: InputDecoration(
                          labelText: "Email",
                          focusColor: Colors.white,
                          hintText: "xxx@gmail.com",
                          border: OutlineInputBorder(
                            borderSide: new BorderSide(color: Color(0xFF2d3447))
                          ),
                          hasFloatingPlaceholder: true,
                          fillColor: Colors.white,
                          prefixIcon: Icon(Icons.email),
                          
                        ),
                      ),
                      Padding
                      (padding: EdgeInsets.only(top: ScreenUtil.instance.setWidth(20))),
                      TextFormField(
                        textInputAction: TextInputAction.done,
                        controller: password,
                        keyboardType: TextInputType.emailAddress,
                        validator: (val){
                          if(val.isEmpty){
                            return 'This field cannot be Empty';
                          }
                        },
                        onChanged: (val){
                          setState(() {
                            val =password.text;
                          });
                        },
                        obscureText: true,
                        decoration: InputDecoration(
                          labelText: "Password",
                          border: OutlineInputBorder(
                            borderSide: new BorderSide(color: Color(0xFF2d3447))
                          ),
                          suffixIcon: Icon(Icons.remove_red_eye),
                          fillColor: Colors.white,
                          focusColor: Colors.white,
                          hasFloatingPlaceholder: true,
                          prefixIcon: Icon(Icons.lock),
                        ),
                      ),
                      Padding
                      (padding: EdgeInsets.only(top: ScreenUtil.instance.setWidth(20))),
                      ProgressButton(
                      buttonState: ButtonState.inProgress,
                      child: Text('Login', style: TextStyle(
                        color: Colors.white,
                        fontFamily: "Mops",
                        fontSize: ScreenUtil.instance.setSp(20),
                        ),
                        ),
                      backgroundColor: Color(0xFF264855), 
                      onPressed: () async {

                      }
                      ),
                    Padding(
                    padding: EdgeInsets.only(top: ScreenUtil.instance.setWidth(0),),
                    child: FlatButton(
                      onPressed: (){
                        setState(() {
                          
                        });
                      }, 
                      child: Text('Forgot Password?',
                      style: TextStyle(
                      fontFamily: "Mops",
                      fontSize: ScreenUtil.instance.setSp(15.0),
                      color: Color(0xFF264855),
                      fontWeight: FontWeight.w100,
                      )),  
                      ),
                    ),
                    ],
                  ),
                  ),
            ),
            ),
          ),
            Padding(padding: EdgeInsets.only(top:ScreenUtil.instance.setWidth(20))),
              Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                    Padding(
                    padding: EdgeInsets.only(top: ScreenUtil.instance.setWidth(100),),
                    child:  Text('Do you have an Account?',
                      style: TextStyle(
                      fontFamily: "Mops",
                      fontSize: ScreenUtil.instance.setSp(20.0),
                      color: Colors.white,
                      fontWeight: FontWeight.w300,
                      )),  
                    ),
                ],
              ),
              FlatButton(
                onPressed: (){
                  setState(() {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => Signup(), fullscreenDialog: true));
                  });
                }, 
                child: Text('Register Here',
                      style: TextStyle(
                      fontFamily: "Mops",
                      fontSize: ScreenUtil.instance.setSp(18.0),
                      color: Colors.lightBlueAccent,
                      fontWeight: FontWeight.w200,
                      )),  
                ),
              
            
          ],
        ),
    ),
    );
  }
}








